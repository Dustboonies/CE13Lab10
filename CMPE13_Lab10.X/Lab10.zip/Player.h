#ifndef PLAYER_H
#define PLAYER_H



#include "UnixBOARD.h"
#include <stdint.h>
// Define how big the player's inventory is.
#define INVENTORY_SIZE 4

/**
 * Adds the specified item to the player's inventory if the inventory isn't full.
 * @param item The item number to be stored: valid values are 0-255.
 * @return SUCCESS if the item was added, STANDARD_ERRROR if the item couldn't be added.
 */
int AddToInventory(uint8_t item);

/**
 * Check if the given item exists in the player's inventory.
 * @param item The number of the item to be searched for: valid values are 0-255.
 * @return SUCCESS if it was found or STANDARD_ERROR if it wasn't.
 */
int FindInInventory(uint8_t item);

#endif // PLAYER_H
